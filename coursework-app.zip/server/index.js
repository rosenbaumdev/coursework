// server/index.js
require("dotenv").config();
const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const Anthropic = require("@anthropic-ai/sdk");

const { SECTIONS, buildEnvelope } = require("./interview-spec");
const { buildBaseSystemPrompt } = require("./base-system-prompt");

const app = express();
app.use(cors());
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "..", "public")));

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

const INTERVIEW_MODEL = "claude-haiku-4-5-20251001";
const PROFILE_MODEL = "claude-sonnet-4-6";

const sessions = {};

function newSession(studentName, studentSlug) {
  return {
    studentName,
    studentSlug,
    currentSection: 1,
    sectionTurnCounts: Object.fromEntries(SECTIONS.map((s) => [s.id, 0])),
    history: [],
    transcriptLog: [],
    completed: false,
    startedAt: new Date().toISOString(),
  };
}

app.post("/api/interview/start", async (req, res) => {
  const { studentName, studentSlug } = req.body;
  if (!studentName || !studentSlug) {
    return res.status(400).json({ error: "studentName and studentSlug required" });
  }

  const sessionId = `${studentSlug}-${Date.now()}`;
  const session = newSession(studentName, studentSlug);
  sessions[sessionId] = session;

  const baseSystem = buildBaseSystemPrompt(studentName);
  const envelope = buildEnvelope(1, studentName);
  const fullSystem = `${baseSystem}\n\n${envelope}`;

  try {
    const response = await anthropic.messages.create({
      model: INTERVIEW_MODEL,
      max_tokens: 1000,
      system: fullSystem,
      messages: [
        {
          role: "user",
          content:
            "[Interview session starting now. Begin Section 1 per your instructions.]",
        },
      ],
    });

    const rawText = response.content
      .filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("\n");

    const { cleanText, sectionComplete } = stripSectionTag(rawText);

    session.history.push({ role: "assistant", content: cleanText });
    session.transcriptLog.push({
      role: "assistant",
      section: session.currentSection,
      raw: rawText,
      sectionComplete,
      ts: new Date().toISOString(),
    });

    res.json({
      sessionId,
      message: cleanText,
      section: session.currentSection,
      sectionName: SECTIONS[session.currentSection - 1].name,
      totalSections: SECTIONS.length,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to start interview", detail: err.message });
  }
});

app.post("/api/interview/message", async (req, res) => {
  const { sessionId, message } = req.body;
  const session = sessions[sessionId];
  if (!session) return res.status(404).json({ error: "Session not found" });
  if (session.completed) return res.status(400).json({ error: "Interview already completed" });

  session.history.push({ role: "user", content: message });
  session.sectionTurnCounts[session.currentSection]++;
  session.transcriptLog.push({
    role: "user",
    section: session.currentSection,
    raw: message,
    ts: new Date().toISOString(),
  });

  const baseSystem = buildBaseSystemPrompt(session.studentName);
  const envelope = buildEnvelope(session.currentSection, session.studentName);
  const fullSystem = `${baseSystem}\n\n${envelope}`;

  try {
    const response = await anthropic.messages.create({
      model: INTERVIEW_MODEL,
      max_tokens: 1000,
      system: fullSystem,
      messages: session.history,
    });

    const rawText = response.content
      .filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("\n");

    const { cleanText, sectionComplete } = stripSectionTag(rawText);

    session.history.push({ role: "assistant", content: cleanText });
    session.transcriptLog.push({
      role: "assistant",
      section: session.currentSection,
      raw: rawText,
      sectionComplete,
      ts: new Date().toISOString(),
    });

    let advanced = false;
    let interviewDone = false;

    const minTurnsMet =
      session.sectionTurnCounts[session.currentSection] >=
      SECTIONS[session.currentSection - 1].minTurns;

    if (sectionComplete && minTurnsMet) {
      if (session.currentSection < SECTIONS.length) {
        session.currentSection++;
        advanced = true;
      } else {
        interviewDone = true;
        session.completed = true;
      }
    }

    res.json({
      message: cleanText,
      section: session.currentSection,
      sectionName: SECTIONS[Math.min(session.currentSection, SECTIONS.length) - 1].name,
      totalSections: SECTIONS.length,
      advanced,
      interviewDone,
    });

    if (interviewDone) {
      generateProfile(session).catch((e) => console.error("Profile gen failed:", e));
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to continue interview", detail: err.message });
  }
});

function stripSectionTag(text) {
  const sectionComplete = /\[SECTION_COMPLETE\]\s*$/.test(text.trim());
  const cleanText = text.replace(/\[SECTION_COMPLETE\]\s*$/, "").trim();
  return { cleanText, sectionComplete };
}

async function generateProfile(session) {
  const transcriptText = session.history
    .map((m) => `${m.role.toUpperCase()}: ${m.content}`)
    .join("\n\n");

  const schemaPrompt = `
You just finished conducting (as Claude) the full onboarding interview with 
${session.studentName} for the "Noob to AI Entrepreneur" course. Below is the 
complete transcript. Generate the full structured profile document now, 
following this exact markdown schema. Fill in real, specific content from 
the transcript — capture his exact phrasing in the Verbatim Language Bank, 
ground Candidate Venture Directions in specific things he said, and don't 
pad thin sections artificially.

SCHEMA TO FOLLOW:

# ${session.studentName} — Onboarding Profile
## Course: Noob to AI Entrepreneur
Interview date: ${new Date().toISOString().slice(0, 10)}
Interviewer: Claude (ingestion interview, pilot v1)

---
## What He Knows / Doesn't Know
### Hands-On Build Experience
### Systems Literacy Map
(Front end/back end, client/server, database, auth, cloud vs local, hardware vs software, UX/UI — each with understood/partial/not-yet + specifics)
Overall calibration:

---
## His Worldview, In His Own Terms

---
## What He Actually Cares About (Energy Map)

---
## Verbatim Language Bank
(8-12 direct quotes with context, if the transcript supports it)

---
## Candidate Venture Directions
(2-4, each with rationale tied to something specific he said)

---
## How He Works
(Stuck-point behavior, completion tendency, feedback sensitivity, structure preference, named anxiety)

---
## Proctor Calibration Notes

---
## Logistics
(Hours/day, time conflicts, starting capital, payment infra status)

---
## What He Said At The End

---
## Flags for Jonathan

---
## Instrument Retro (pilot notes — separate from student data)
(Your honest notes on how the interview instrument itself performed)

TRANSCRIPT:
${transcriptText}
`.trim();

  const response = await anthropic.messages.create({
    model: PROFILE_MODEL,
    max_tokens: 4000,
    messages: [{ role: "user", content: schemaPrompt }],
  });

  const profileText = response.content
    .filter((b) => b.type === "text")
    .map((b) => b.text)
    .join("\n");

  const studentDir = path.join(
    __dirname,
    "..",
    "data",
    "students",
    session.studentSlug
  );
  fs.mkdirSync(studentDir, { recursive: true });

  fs.writeFileSync(
    path.join(studentDir, `${session.studentSlug}-profile.md`),
    profileText
  );

  fs.writeFileSync(
    path.join(studentDir, `${session.studentSlug}-interview-transcript.json`),
    JSON.stringify(session.transcriptLog, null, 2)
  );

  console.log(`✅ Profile generated for ${session.studentName} → ${studentDir}`);
}

app.get("/api/interview/:sessionId/status", (req, res) => {
  const session = sessions[req.params.sessionId];
  if (!session) return res.status(404).json({ error: "Not found" });
  res.json({
    completed: session.completed,
    currentSection: session.currentSection,
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Coursework ingestion app running on port ${PORT}`);
});
