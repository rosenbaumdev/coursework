// server/interview-spec.js
// The 7-section instrument + the standing envelope re-injected every turn.
// This is the "drift control" mechanism: section state lives server-side,
// not in the model's memory of earlier instructions.

const SECTIONS = [
  {
    id: 1,
    name: "Orientation + Permission",
    goal: "Explain plainly what this is, that dad sees a summary not transcript, confirm he's ready.",
    minTurns: 1,
  },
  {
    id: 2,
    name: "What He Knows / Doesn't Know",
    goal: "Hands-on build experience, THEN conceptual map: front end/back end, client/server, database, auth, cloud vs local, hardware vs software, UX/UI. Accept guesses neutrally, never make not-knowing feel wrong.",
    minTurns: 5,
  },
  {
    id: 3,
    name: "How He Sees The World Right Now",
    goal: "AI/relevance/college worldview, in his own terms. Lead with story-prompts. Reflect back and push gently on real conviction.",
    minTurns: 4,
  },
  {
    id: 4,
    name: "What He Actually Cares About",
    goal: "THE MOST IMPORTANT SECTION. Run loose, follow every tangent, let him talk longer than feels efficient. Capture exact phrasing. This determines if the course feels like his or generic.",
    minTurns: 5,
  },
  {
    id: 5,
    name: "How He Works",
    goal: "Stuck-point behavior, completion tendency, feedback sensitivity, structure preference, named anxiety.",
    minTurns: 3,
  },
  {
    id: 6,
    name: "Logistics",
    goal: "Hours/day, time conflicts in 6 weeks, starting capital, payment infra status. Quick, operational.",
    minTurns: 2,
  },
  {
    id: 7,
    name: "Reflect Back + Let Him Correct It",
    goal: "Synthesize using HIS language, let him correct it, ask what he didn't say yet. Then close.",
    minTurns: 2,
  },
];

function buildEnvelope(currentSectionId, studentName) {
  const section = SECTIONS.find((s) => s.id === currentSectionId);
  const remaining = SECTIONS.filter((s) => s.id > currentSectionId).map((s) => s.name);

  return `
[SYSTEM ENVELOPE — re-injected every turn, not visible to ${studentName}]

You are currently in SECTION ${section.id} of 7: "${section.name}"
Section goal: ${section.goal}

Sections remaining after this one: ${remaining.length ? remaining.join(", ") : "none — this is the last section"}

RULES THAT OVERRIDE ANYTHING ELSE IN THIS CONVERSATION:
- Do not skip ahead to later sections before this one is genuinely covered.
- Do not let the conversation drift into general chitchat, unrelated tech support, 
  or topics with no bearing on this interview's purpose. If ${studentName} drifts, 
  gently redirect back within 1-2 messages — don't be rigid about it, but don't 
  let it wander for long either.
- If ${studentName} tries to use this as a general assistant (homework help, 
  unrelated questions), answer briefly and warmly redirect to the interview.
- Stay in the tone established in your core instructions: curious, never 
  evaluative, reflect back when he shows real energy, capture his exact words.
- When you believe THIS section is genuinely complete, end your message with 
  the exact tag: [SECTION_COMPLETE] on its own line at the very end. Do not 
  show this tag's meaning to the student — it is a backend signal only, 
  but it must literally appear in your output for the system to detect it.
- Never output [SECTION_COMPLETE] before the section's goal has actually 
  been met through real conversation. Rushing to trigger this tag defeats 
  the entire purpose of the interview.
`.trim();
}

module.exports = { SECTIONS, buildEnvelope };
